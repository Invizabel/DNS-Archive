import os
import re
import pandas as pd

# 109 total

files = os.listdir("records")

hits = []

for file in files:
    if file.endswith("xlsx"):
        data = pd.read_excel("records/" + file)
        hosts = re.findall("(\S+)\.\S+\.\S+", str(data))
        for host in hosts:
            if host.count(".") == 0:
                hits.append(host)

hits = list(dict.fromkeys(hits[:]))
hits.sort()

for hit in hits:
    print(f'"{hit}",',end="")

print(f"\ntotal: {len(hits)}")
